/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.80353634577604, "KoPercent": 0.19646365422396855};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.40078585461689586, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.1, 500, 1500, "Agent Login"], "isController": false}, {"data": [1.0, 500, 1500, "System Virtual Money Creation"], "isController": false}, {"data": [0.29, 500, 1500, "Deposit Agent To Customer 2"], "isController": false}, {"data": [0.72, 500, 1500, "Search Transaction By Transaction ID"], "isController": false}, {"data": [1.0, 500, 1500, "Deposit System To Customer"], "isController": false}, {"data": [0.66, 500, 1500, "Transaction History"], "isController": false}, {"data": [0.4, 500, 1500, "Payment Customer 1 to Merchant"], "isController": false}, {"data": [0.5, 500, 1500, "Withdraw Customer 2 To Agent"], "isController": false}, {"data": [1.0, 500, 1500, "Save all local data to global(Easily accessible from one thread group to another)"], "isController": false}, {"data": [0.34, 500, 1500, "Send Money Customer 2 To Customer 1"], "isController": false}, {"data": [0.5, 500, 1500, "Admin Login"], "isController": false}, {"data": [0.17, 500, 1500, "Customer 2 Login"], "isController": false}, {"data": [0.5, 500, 1500, "Create Customer"], "isController": false}, {"data": [0.14, 500, 1500, "Customer Login"], "isController": false}, {"data": [0.5, 500, 1500, "Create Customer 2"], "isController": false}, {"data": [1.0, 500, 1500, "Create Merchant"], "isController": false}, {"data": [1.0, 500, 1500, "Create Agent"], "isController": false}, {"data": [1.0, 500, 1500, "Deposit System To Agent"], "isController": false}, {"data": [0.61, 500, 1500, "Check Customer 1 Balance"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 509, 1, 0.19646365422396855, 1446.8015717092337, 62, 6879, 1218.0, 2897.0, 3190.0, 3473.899999999999, 16.71263462043604, 13.753415531832808, 9.436320532079066], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Agent Login", 50, 0, 0.0, 2240.46, 520, 3361, 2354.5, 3251.2, 3298.5499999999997, 3361.0, 2.2092612230470134, 1.5080796825291622, 0.612724792329445], "isController": false}, {"data": ["System Virtual Money Creation", 1, 0, 0.0, 125.0, 125, 125, 125.0, 125.0, 125.0, 125.0, 8.0, 2.7890625, 5.765625], "isController": false}, {"data": ["Deposit Agent To Customer 2", 50, 1, 2.0, 1564.78, 197, 2836, 1673.0, 2608.9, 2652.0499999999997, 2836.0, 2.212781023189945, 1.6882827712869535, 1.6271719828730749], "isController": false}, {"data": ["Search Transaction By Transaction ID", 50, 0, 0.0, 717.6999999999998, 93, 2713, 382.5, 2357.6999999999994, 2570.8499999999995, 2713.0, 2.306911506874596, 1.4053236308480208, 1.4260497889175971], "isController": false}, {"data": ["Deposit System To Customer", 1, 0, 0.0, 155.0, 155, 155, 155.0, 155.0, 155.0, 155.0, 6.451612903225806, 2.665070564516129, 4.706401209677419], "isController": false}, {"data": ["Transaction History", 50, 0, 0.0, 862.1600000000001, 171, 2897, 498.0, 2370.7, 2619.9499999999994, 2897.0, 2.2627505996289092, 7.929217272141014, 1.4274774290627685], "isController": false}, {"data": ["Payment Customer 1 to Merchant", 50, 0, 0.0, 1313.5400000000002, 314, 3059, 1160.0, 2507.4, 2732.449999999999, 3059.0, 2.1978988087388456, 0.7682343179919997, 1.5969108532243177], "isController": false}, {"data": ["Withdraw Customer 2 To Agent", 50, 0, 0.0, 1132.88, 249, 3078, 742.0, 2458.0, 2783.4499999999994, 3078.0, 2.214545132429799, 0.7458951329834352, 1.6111680895119143], "isController": false}, {"data": ["Save all local data to global(Easily accessible from one thread group to another)", 1, 0, 0.0, 62.0, 62, 62, 62.0, 62.0, 62.0, 62.0, 16.129032258064516, 0.0, 0.0], "isController": false}, {"data": ["Send Money Customer 2 To Customer 1", 50, 0, 0.0, 1467.6, 201, 3427, 1299.0, 2591.3, 2968.3499999999995, 3427.0, 2.208578117408013, 0.7635123569945669, 1.608983667564822], "isController": false}, {"data": ["Admin Login", 1, 0, 0.0, 1155.0, 1155, 1155, 1155.0, 1155.0, 1155.0, 1155.0, 0.8658008658008658, 0.588474025974026, 0.23589691558441558], "isController": false}, {"data": ["Customer 2 Login", 50, 0, 0.0, 2204.5, 347, 3543, 2383.5, 3312.6, 3432.05, 3543.0, 2.3669759515243323, 1.6319189665782996, 0.6703349862715395], "isController": false}, {"data": ["Create Customer", 1, 0, 0.0, 725.0, 725, 725, 725.0, 725.0, 725.0, 725.0, 1.379310344827586, 0.6963900862068966, 1.1233836206896552], "isController": false}, {"data": ["Customer Login", 50, 0, 0.0, 2186.14, 503, 6879, 2129.5, 3400.7, 3650.649999999999, 6879.0, 2.610420799832933, 1.799762778009815, 0.741828567140023], "isController": false}, {"data": ["Create Customer 2", 1, 0, 0.0, 581.0, 581, 581, 581.0, 581.0, 581.0, 581.0, 1.721170395869191, 0.8790743330464716, 1.41021675989673], "isController": false}, {"data": ["Create Merchant", 1, 0, 0.0, 420.0, 420, 420, 420.0, 420.0, 420.0, 420.0, 2.3809523809523814, 1.220703125, 1.9507998511904763], "isController": false}, {"data": ["Create Agent", 1, 0, 0.0, 494.0, 494, 494, 494.0, 494.0, 494.0, 494.0, 2.0242914979757085, 1.0220299848178138, 1.6328757591093117], "isController": false}, {"data": ["Deposit System To Agent", 1, 0, 0.0, 112.0, 112, 112, 112.0, 112.0, 112.0, 112.0, 8.928571428571429, 3.11279296875, 6.434849330357142], "isController": false}, {"data": ["Check Customer 1 Balance", 50, 0, 0.0, 962.0999999999997, 156, 2931, 566.5, 2315.9, 2595.0, 2931.0, 2.244165170556553, 0.7429413992369838, 1.3960285289497307], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 1, 100.0, 0.19646365422396855], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 509, 1, "500/Internal Server Error", 1, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Deposit Agent To Customer 2", 50, 1, "500/Internal Server Error", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
